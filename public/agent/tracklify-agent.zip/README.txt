Tracklify Agent Installation Guide
----------------------------------

1. Unzip this file on the target computer.
2. Inside, you'll find a sample agent script (Python-based).
3. Run the script using Python 3:
   $ python tracklify_agent.py
4. This script simulates activity tracking and sends logs to your backend (to be implemented).
5. In production, replace this with a compiled .exe or real script that connects to Supabase.
