import time
print('Tracklify Agent Started')
for i in range(10):
    print(f'Activity Log {i+1}: User is active')
    time.sleep(1)
print('Tracklify Agent Finished')
